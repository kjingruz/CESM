# PCB Holes > 2023-08-02 6:09pm
https://universe.roboflow.com/rf-projects/pcb-holes

Provided by a Roboflow user
License: CC BY 4.0


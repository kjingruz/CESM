# axial MRI > release
https://universe.roboflow.com/object-detection/axial-mri

Provided by Roboflow
License: CC BY 4.0

